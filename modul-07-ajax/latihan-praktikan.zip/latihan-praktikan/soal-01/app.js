document.getElementById('waktu-awal').textContent = new Date().toLocaleTimeString();

let hitungan = 0;
document.getElementById('btn-hitung').addEventListener('click', () => {
    hitungan++;
    document.getElementById('angka-hitungan').textContent = hitungan;
});

document.getElementById('btn-pengumuman').addEventListener('click', function() {
    const btn = this;
    const loading = document.getElementById('loading-pengumuman');
    const tempat = document.getElementById('tempat-pengumuman');
    
    btn.disabled = true;
    loading.style.display = 'block';
    tempat.textContent = '';

    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'pengumuman.txt', true); 
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            btn.disabled = false;
            loading.style.display = 'none';
            
            if (xhr.status === 200) {
                tempat.textContent = xhr.responseText;
            } else {
                tempat.textContent = `Gagal memuat pengumuman. Status: HTTP ${xhr.status}`;
            }
        }
    };
    
    xhr.onerror = function() {
        btn.disabled = false;
        loading.style.display = 'none';
        tempat.textContent = 'Gagal jaringan saat memuat pengumuman.';
    };
    
    xhr.send();
});

document.getElementById('btn-peserta').addEventListener('click', async function() {
    const btn = this;
    const sumber = document.getElementById('sumber-data').value;
    const loading = document.getElementById('loading-peserta');
    const tempat = document.getElementById('tempat-peserta');
    
    btn.disabled = true;
    loading.style.display = 'block';
    tempat.innerHTML = '';
    
    let url = sumber === 'mock' 
        ? '/api/users?delay=1500' 
        : 'https://jsonplaceholder.typicode.com/users';

    try {
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const data = await response.json();
        const maxData = data.slice(0, 3); 
        
        let html = `<p><strong>Sumber:</strong> ${sumber === 'mock' ? 'API Lokal' : 'JSONPlaceholder'}</p>`;
        html += `<p><strong>Jumlah ditampilkan:</strong> ${maxData.length}</p><ul>`;
        
        maxData.forEach(user => {
            html += `<li>${user.name} (${user.email})</li>`;
        });
        html += '</ul>';
        
        tempat.innerHTML = html;
        
    } catch (error) {
        tempat.innerHTML = `<p style="color:red;">Gagal mengambil data peserta: ${error.message}. Periksa koneksi internet Anda atau gunakan Mock lokal.</p>`;
    } finally {
        btn.disabled = false;
        loading.style.display = 'none';
    }
});