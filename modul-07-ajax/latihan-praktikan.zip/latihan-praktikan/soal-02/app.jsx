const { useState, useEffect } = React;

function App() {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [scenario, setScenario] = useState('berhasil');
    const [trigger, setTrigger] = useState(0);

    const [formData, setFormData] = useState({ name: '', email: '' });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [postResult, setPostResult] = useState(null);
    const [formError, setFormError] = useState('');

    const scenarios = {
        berhasil: { url: '/api/users?delay=1000', timeout: 5000 },
        kosong: { url: '/api/users?mode=empty&delay=1000', timeout: 5000 },
        errorHTTP: { url: '/api/users?mode=error&delay=1000', timeout: 5000 },
        timeout: { url: '/api/users?delay=2500', timeout: 700 }
    };

    useEffect(() => {
        const config = scenarios[scenario];
        const controller = new AbortController();
        
        const fetchUsers = async () => {
            setLoading(true);
            setError(null);
            setUsers([]);

            try {
                const response = await axios.get(config.url, {
                    signal: controller.signal,
                    timeout: config.timeout
                });
                
                if (response.data.length === 0) {
                    setError("Data kosong.");
                } else {
                    setUsers(response.data);
                }
            } catch (err) {
                if (axios.isCancel(err)) {
                    console.log('Request dibatalkan karena perubahan pilihan.');
                } else if (err.code === 'ECONNABORTED') {
                    setError('Request Timeout.');
                } else {
                    setError(`Error HTTP: ${err.message}`);
                }
            } finally {
                setLoading(false);
            }
        };

        fetchUsers();

        return () => controller.abort();
    }, [scenario, trigger]);

    const handleRegister = async (e) => {
        e.preventDefault();
        setFormError('');
        setPostResult(null);

        const trimmedName = formData.name.trim();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Validasi
        if (!trimmedName) {
            setFormError("Nama tidak boleh kosong atau hanya spasi.");
            return;
        }
        if (!emailPattern.test(formData.email)) {
            setFormError("Format email tidak valid.");
            return;
        }

        setIsSubmitting(true);
        try {
            const response = await axios.post('/api/users', {
                name: trimmedName,
                email: formData.email
            });
            
            setPostResult({
                status: response.status,
                ...response.data
            });
            setFormData({ name: '', email: '' }); // Kosongkan form setelah sukses
        } catch (err) {
            setFormError(`Gagal mengirim pendaftaran: ${err.message}`);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div style={{ fontFamily: 'sans-serif', padding: '20px' }}>
            <h2>Daftar Peserta (GET)</h2>
            <label>Pilih Skenario: </label>
            <select value={scenario} onChange={(e) => setScenario(e.target.value)}>
                <option value="berhasil">Berhasil</option>
                <option value="kosong">Data kosong</option>
                <option value="errorHTTP">Error HTTP</option>
                <option value="timeout">Timeout</option>
            </select>
            <button onClick={() => setTrigger(prev => prev + 1)} style={{ marginLeft: '10px' }}>
                Muat ulang
            </button>

            <div style={{ marginTop: '15px', padding: '15px', border: '1px solid #ccc', minHeight: '100px' }}>
                {loading && <p style={{ color: 'blue' }}>Memuat data peserta...</p>}
                {error && <p style={{ color: 'red', fontWeight: 'bold' }}>{error}</p>}
                {!loading && !error && users.length > 0 && (
                    <ul>
                        {users.map(user => (
                            <li key={user.id}>{user.name} ({user.email})</li>
                        ))}
                    </ul>
                )}
            </div>

            <hr style={{ margin: '30px 0' }} />

            <h2>Pendaftaran Peserta (POST)</h2>
            <form onSubmit={handleRegister}>
                <div style={{ marginBottom: '10px' }}>
                    <label style={{ display: 'inline-block', width: '60px' }}>Nama: </label>
                    <input 
                        type="text" 
                        value={formData.name} 
                        onChange={e => setFormData({...formData, name: e.target.value})} 
                    />
                </div>
                <div style={{ marginBottom: '10px' }}>
                    <label style={{ display: 'inline-block', width: '60px' }}>Email: </label>
                    <input 
                        type="text" 
                        value={formData.email} 
                        onChange={e => setFormData({...formData, email: e.target.value})} 
                    />
                </div>
                {formError && <p style={{ color: 'red' }}>{formError}</p>}
                
                <button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? 'Mengirim...' : 'Kirim Pendaftaran'}
                </button>
            </form>

            {postResult && (
                <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#e6ffe6', border: '1px solid green' }}>
                    <p><strong>Status HTTP:</strong> {postResult.status}</p>
                    <p><strong>ID:</strong> {postResult.id}</p>
                    <p><strong>Nama:</strong> {postResult.name}</p>
                    <p><strong>Email:</strong> {postResult.email}</p>
                    <p style={{ color: 'green', marginTop: '10px' }}>
                        <em>Simulasi berhasil, data tidak disimpan (simulated: {postResult.simulated.toString()}).</em>
                    </p>
                </div>
            )}
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);