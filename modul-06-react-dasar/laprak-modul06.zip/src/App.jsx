import { useState } from 'react';

function RingkasanPeserta({ total, hadir, belumHadir, tampil }) {
  return (
    <div style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ccc', borderRadius: '5px' }}>
      <h3>Ringkasan Peserta</h3>
      <p>
        <strong>Total peserta:</strong> {total} | <strong>Hadir:</strong> {hadir} | <strong>Belum hadir:</strong> {belumHadir} | <strong>Hasil ditampilkan:</strong> {tampil}
      </p>
    </div>
  );
}

function FormPeserta({ formData, handleInputChange, handleSubmit, editId, handleCancelEdit, errorMsg }) {
  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ccc', borderRadius: '5px' }}>
      <h3>{editId ? 'Edit Peserta' : 'Tambah Peserta'}</h3>
      {errorMsg && <p style={{ color: 'red', fontWeight: 'bold' }}>{errorMsg}</p>}
      
      <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
        <input
          type="text"
          name="nama"
          placeholder="Nama Mahasiswa"
          value={formData.nama}
          onChange={handleInputChange}
        />
        <input
          type="text"
          name="nim"
          placeholder="NIM (8 digit)"
          value={formData.nim}
          onChange={handleInputChange}
        />
        <select name="kelas" value={formData.kelas} onChange={handleInputChange}>
          <option value="">Pilih kelas</option>
          <option value="TI-2A">TI-2A</option>
          <option value="TI-2B">TI-2B</option>
        </select>
      </div>

      <button type="submit" style={{ marginRight: '10px' }}>
        {editId ? 'Simpan perubahan' : 'Tambah peserta'}
      </button>
      {editId && (
        <button type="button" onClick={handleCancelEdit}>
          Batal
        </button>
      )}
    </form>
  );
}

function FilterPeserta({ searchQuery, setSearchQuery, filterKelas, setFilterKelas }) {
  return (
    <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
      <input
        type="text"
        placeholder="Cari nama atau NIM..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        style={{ flex: 1 }}
      />
      <select value={filterKelas} onChange={(e) => setFilterKelas(e.target.value)}>
        <option value="Semua kelas">Semua kelas</option>
        <option value="TI-2A">TI-2A</option>
        <option value="TI-2B">TI-2B</option>
      </select>
    </div>
  );
}

function ItemPeserta({ p, handleEditClick, handleDelete, handleToggleKehadiran }) {
  return (
    <li style={{ border: '1px solid #eee', padding: '10px', marginBottom: '10px', borderRadius: '5px' }}>
      <div>
        <strong>{p.nama}</strong> ({p.nim}) - {p.kelas} 
        <span style={{ marginLeft: '10px', color: p.kehadiran ? 'green' : 'red' }}>
          [{p.kehadiran ? 'Hadir' : 'Belum hadir'}]
        </span>
      </div>
      <div style={{ marginTop: '10px', display: 'flex', gap: '10px' }}>
        <button onClick={() => handleToggleKehadiran(p.id)}>
          {p.kehadiran ? 'Batalkan hadir' : 'Tandai hadir'}
        </button>
        <button onClick={() => handleEditClick(p)}>Edit</button>
        <button onClick={() => handleDelete(p.id)}>Hapus</button>
      </div>
    </li>
  );
}

function DaftarPeserta({ totalData, pesertaList, handleEditClick, handleDelete, handleToggleKehadiran }) {
  if (totalData === 0) {
    return <p style={{ fontWeight: 'bold' }}>Belum ada peserta.</p>;
  }
  if (pesertaList.length === 0) {
    return <p style={{ fontWeight: 'bold' }}>Peserta tidak ditemukan.</p>;
  }

  return (
    <ul style={{ listStyleType: 'none', padding: 0 }}>
      {pesertaList.map((p) => (
        <ItemPeserta
          key={p.id}
          p={p}
          handleEditClick={handleEditClick}
          handleDelete={handleDelete}
          handleToggleKehadiran={handleToggleKehadiran}
        />
      ))}
    </ul>
  );
}

export default function App() {
  const [peserta, setPeserta] = useState([
    { id: 'm-1', nama: 'Ani', nim: '10121001', kelas: 'TI-2A', kehadiran: true },
    { id: 'm-2', nama: 'Budi', nim: '10121002', kelas: 'TI-2B', kehadiran: false },
    { id: 'm-3', nama: 'Citra', nim: '10121003', kelas: 'TI-2A', kehadiran: false },
  ]);

  const [formData, setFormData] = useState({ nama: '', nim: '', kelas: '' });
  const [editId, setEditId] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  const [searchQuery, setSearchQuery] = useState('');
  const [filterKelas, setFilterKelas] = useState('Semua kelas');

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const namaClean = formData.nama.trim();
    const nimClean = formData.nim.trim();
    const kelas = formData.kelas;

    if (namaClean.length < 3) {
      setErrorMsg('Nama wajib diisi dan memiliki sedikitnya 3 karakter.');
      return;
    }
    if (nimClean.length !== 8 || !/^\d{8}$/.test(nimClean)) {
      setErrorMsg('NIM wajib terdiri atas tepat 8 digit angka.');
      return;
    }
    if (kelas !== 'TI-2A' && kelas !== 'TI-2B') {
      setErrorMsg('Silakan pilih kelas yang valid (TI-2A atau TI-2B).');
      return;
    }

    const isNimTaken = peserta.some((p) => p.nim === nimClean && p.id !== editId);
    if (isNimTaken) {
      setErrorMsg('NIM sudah digunakan oleh peserta lain.');
      return;
    }

    if (editId) {
      setPeserta(
        peserta.map((p) => (p.id === editId ? { ...p, nama: namaClean, nim: nimClean, kelas: kelas } : p))
      );
      setEditId(null);
    } else {
      const newId = `m-${Date.now()}`;
      setPeserta([...peserta, { id: newId, nama: namaClean, nim: nimClean, kelas: kelas, kehadiran: false }]);
    }
    
    setFormData({ nama: '', nim: '', kelas: '' });
    setErrorMsg('');
  };

  const handleEditClick = (p) => {
    setFormData({ nama: p.nama, nim: p.nim, kelas: p.kelas });
    setEditId(p.id);
    setErrorMsg('');
  };

  const handleCancelEdit = () => {
    setFormData({ nama: '', nim: '', kelas: '' });
    setEditId(null);
    setErrorMsg('');
  };

  const handleDelete = (id) => {
    if (editId === id) {
      handleCancelEdit();
    }
    setPeserta(peserta.filter((p) => p.id !== id));
  };

  const handleToggleKehadiran = (id) => {
    setPeserta(peserta.map((p) => (p.id === id ? { ...p, kehadiran: !p.kehadiran } : p)));
  };

  const searchClean = searchQuery.trim().toLowerCase();
  const filteredPeserta = peserta.filter((p) => {
    const matchSearch = p.nama.toLowerCase().includes(searchClean) || p.nim.toLowerCase().includes(searchClean);
    const matchKelas = filterKelas === 'Semua kelas' || p.kelas === filterKelas;
    return matchSearch && matchKelas;
  });

  const total = peserta.length;
  const hadir = peserta.filter((p) => p.kehadiran).length;
  const belumHadir = total - hadir;
  const tampil = filteredPeserta.length;

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px', fontFamily: 'Arial, sans-serif', textAlign: 'left' }}>
      <h1 style={{ textAlign: 'center', lineHeight: '1.5', marginBottom: '30px', display: 'block' }}>
        Aplikasi Manajemen Peserta Praktikum
      </h1>
      
      <RingkasanPeserta total={total} hadir={hadir} belumHadir={belumHadir} tampil={tampil} />
      
      <FormPeserta 
        formData={formData} 
        handleInputChange={handleInputChange} 
        handleSubmit={handleSubmit} 
        editId={editId} 
        handleCancelEdit={handleCancelEdit} 
        errorMsg={errorMsg} 
      />
      
      <FilterPeserta 
        searchQuery={searchQuery} 
        setSearchQuery={setSearchQuery} 
        filterKelas={filterKelas} 
        setFilterKelas={setFilterKelas} 
      />
      
      <h2>Daftar Peserta</h2>
      <DaftarPeserta 
        totalData={peserta.length}
        pesertaList={filteredPeserta} 
        handleEditClick={handleEditClick} 
        handleDelete={handleDelete} 
        handleToggleKehadiran={handleToggleKehadiran} 
      />
    </div>
  );
}