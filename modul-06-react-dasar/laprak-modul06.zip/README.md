# Aplikasi Manajemen Peserta Praktikum

## Cara Menjalankan Program
1. Buka terminal di folder proyek.
2. Jalankan `npm install`
3. Jalankan `npm run dev`
4. Buka URL localhost yang muncul di browser.